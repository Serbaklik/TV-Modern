function doGet(e) {
  const page = (e && e.parameter && e.parameter.page) ? String(e.parameter.page).toLowerCase() : 'dashboard';

  if (page === 'admin') {
    const tpl = HtmlService.createTemplateFromFile('admin');
    tpl.appData = getAdminData();
    return tpl.evaluate()
      .setTitle('Admin TV Digital')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  }

  const tpl = HtmlService.createTemplateFromFile('index');
  tpl.appData = getDashboardData();
  return tpl.evaluate()
    .setTitle(getSetting_('dashboard_title', 'Dashboard TV Digital'))
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function getDashboardData() {
  return {
    settings: getSettings(),
    theme: getTheme(),
    promos: getPromos(),
    queues: getQueues(),
    services: getServices(),
    generatedAt: new Date().toISOString()
  };
}

function getAdminData() {
  return getDashboardData();
}
