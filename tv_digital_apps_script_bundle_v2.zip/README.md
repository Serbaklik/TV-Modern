# TV Digital Apps Script Bundle v2

## File
- Code.gs
- DataService.gs
- index.html
- styles.html
- script.html
- admin.html
- admin_styles.html
- admin_script.html

## Fitur
- Dashboard TV digital
- Auto-slide promo
- Auto-refresh data dari Google Sheets
- Halaman admin sederhana
- Simpan data inti kembali ke sheet

## Akses
- Dashboard: `.../exec`
- Admin: `.../exec?page=admin`

## Sheet wajib
- settings
- promo_items
- queue_list
- services
- theme

## Catatan
Jika sheet belum ada, buat manual atau jalankan fungsi `ensureTemplateSheets()` sekali dari editor Apps Script.
