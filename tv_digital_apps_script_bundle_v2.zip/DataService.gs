const SHEET_NAMES = {
  settings: 'settings',
  promoItems: 'promo_items',
  queueList: 'queue_list',
  services: 'services',
  theme: 'theme'
};

function getSpreadsheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  if (!ss) throw new Error('Spreadsheet aktif tidak ditemukan. Script harus terikat ke Google Sheets.');
  return ss;
}

function getOrCreateSheet_(sheetName) {
  const ss = getSpreadsheet_();
  let sh = ss.getSheetByName(sheetName);
  if (!sh) sh = ss.insertSheet(sheetName);
  return sh;
}

function getSheetRows_(sheetName) {
  const sh = getSpreadsheet_().getSheetByName(sheetName);
  if (!sh) return [];
  const values = sh.getDataRange().getValues();
  if (values.length <= 1) return [];
  const headers = values[0].map(h => String(h || '').trim());
  return values.slice(1)
    .filter(row => row.some(cell => String(cell || '').trim() !== ''))
    .map((row, idx) => {
      const obj = { _row: idx + 2 };
      headers.forEach((header, i) => obj[header] = row[i]);
      return obj;
    });
}

function getSettings() {
  const rows = getSheetRows_(SHEET_NAMES.settings);
  const out = {};
  rows.forEach(r => {
    const key = String(r.key || '').trim();
    if (key) out[key] = r.value;
  });
  return out;
}

function getTheme() {
  const rows = getSheetRows_(SHEET_NAMES.theme);
  const out = {};
  rows.forEach(r => {
    const key = String(r.element || '').trim();
    if (key) out[key] = r.color_value;
  });
  return out;
}

function getPromos() {
  return getSheetRows_(SHEET_NAMES.promoItems)
    .filter(r => isTruthy_(r.active))
    .map(r => ({
      _row: r._row,
      id: r.id || '',
      title: r.title || '',
      price: r.price || '',
      badge: r.badge || '',
      image_url: r.image_url || '',
      order_no: Number(r.order_no || 0)
    }))
    .sort((a, b) => a.order_no - b.order_no);
}

function getQueues() {
  return getSheetRows_(SHEET_NAMES.queueList)
    .filter(r => isTruthy_(r.active))
    .map(r => ({
      _row: r._row,
      queue_no: r.queue_no || '',
      status_text: r.status_text || '',
      status_code: String(r.status_code || 'waiting').toLowerCase(),
      icon: r.icon || '',
      updated_at: r.updated_at || '',
      order_no: Number(r.order_no || 0)
    }))
    .sort((a, b) => a.order_no - b.order_no);
}

function getServices() {
  return getSheetRows_(SHEET_NAMES.services)
    .filter(r => isTruthy_(r.active))
    .map(r => ({
      _row: r._row,
      id: r.id || '',
      service_title: r.service_title || '',
      icon_name: r.icon_name || '',
      order_no: Number(r.order_no || 0)
    }))
    .sort((a, b) => a.order_no - b.order_no);
}

function getSetting_(key, fallback) {
  const settings = getSettings();
  return settings[key] !== undefined && settings[key] !== null && String(settings[key]).trim() !== ''
    ? settings[key]
    : fallback;
}

function isTruthy_(value) {
  if (value === true) return true;
  const s = String(value || '').trim().toLowerCase();
  return ['true', 'yes', 'y', '1', 'aktif', 'active'].includes(s);
}

function saveAdminData(payload) {
  payload = payload || {};
  if (payload.settings) writeSettings_(payload.settings);
  if (payload.promos) writeRows_(SHEET_NAMES.promoItems, [
    'id','title','price','badge','image_url','order_no','active'
  ], payload.promos, ['id','title','price','badge','image_url','order_no','active']);
  if (payload.queues) writeRows_(SHEET_NAMES.queueList, [
    'queue_no','status_text','status_code','icon','updated_at','order_no','active'
  ], payload.queues, ['queue_no','status_text','status_code','icon','updated_at','order_no','active']);
  if (payload.services) writeRows_(SHEET_NAMES.services, [
    'id','service_title','icon_name','order_no','active'
  ], payload.services, ['id','service_title','icon_name','order_no','active']);

  return {
    ok: true,
    data: getAdminData()
  };
}

function writeSettings_(settingsArr) {
  const sh = getOrCreateSheet_(SHEET_NAMES.settings);
  const headers = ['key', 'value'];
  sh.clearContents();
  sh.getRange(1, 1, 1, headers.length).setValues([headers]);

  const rows = (settingsArr || []).map(item => [item.key || '', item.value ?? '']);
  if (rows.length) sh.getRange(2, 1, rows.length, headers.length).setValues(rows);
}

function writeRows_(sheetName, headers, items, fields) {
  const sh = getOrCreateSheet_(sheetName);
  sh.clearContents();
  sh.getRange(1, 1, 1, headers.length).setValues([headers]);

  const rows = (items || []).map(item => fields.map(f => item[f] ?? ''));
  if (rows.length) sh.getRange(2, 1, rows.length, headers.length).setValues(rows);
}

function ensureTemplateSheets() {
  const templates = {
    settings: [['key', 'value']],
    promo_items: [['id', 'title', 'price', 'badge', 'image_url', 'order_no', 'active']],
    queue_list: [['queue_no', 'status_text', 'status_code', 'icon', 'updated_at', 'order_no', 'active']],
    services: [['id', 'service_title', 'icon_name', 'order_no', 'active']],
    theme: [['element', 'color_value']]
  };
  Object.keys(templates).forEach(name => {
    const sh = getOrCreateSheet_(name);
    if (sh.getLastRow() === 0) {
      sh.getRange(1, 1, 1, templates[name][0].length).setValues(templates[name]);
    }
  });
  return true;
}
